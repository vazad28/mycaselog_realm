part of 'settings_repository_impl.dart';

abstract class SettingsRepository {
  /// get settings support data
  SettingsModel getAppSettings();

  /// update settings support data
  Future<Result<SettingsModel, RepositoryFailure>> setAppSettings(
    SettingsModel settingsModel,
  );
}
