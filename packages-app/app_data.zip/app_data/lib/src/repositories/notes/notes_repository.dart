part of 'notes_repository_impl.dart';

/// Abstract class for the notes repositoru
abstract class NotesRepository {
  RealmResults<NoteModel> loadNotes();

  // Get list of  note models
  // Future<Result<List<NoteModel>, RepositoryFailure>> getNotes(
  //   int offset,
  //   int limit,
  // );

  // Get list of  note models
  NoteModel? getLastUpdatedNote();

  // Get total note count for enless list view
  FutureOr<int> getTotalNoteCount();

  // Get  single noteModel by noteID
  NoteModel? getNote(String noteID);

  // Add a new note
  Future<Result<NoteModel, RepositoryFailure>> addNote(NoteModel noteModel);

  /// Remove note data (set removed flag to 1)
  Future<Result<Unit, RepositoryFailure>> deleteNote(NoteModel noteModel);

  /// fet the list of notes with status of removed
  Iterable<NoteModel> fetchRemovedNotesList();
}
