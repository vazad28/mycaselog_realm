import 'dart:async';

import 'package:app_models/app_models.dart';
import 'package:async_result/async_result.dart';
import 'package:realm/realm.dart';

import '../../../../../app_data.dart';

part 'notes_repository.dart';

class NotesRepositoryImpl implements NotesRepository {
  NotesRepositoryImpl({
    required DatabaseService databaseService,
  }) : _databaseService = databaseService;

  final DatabaseService _databaseService;

  @override
  Future<Result<NoteModel, RepositoryFailure>> addNote(
    NoteModel noteModel,
  ) async {
    try {
      await _databaseService.notesCollection.upsert(noteModel);
      return Result.success(noteModel);
    } catch (err) {
      return Result.failure(RepositoryFailure.fromError(err));
    }
  }

  @override
  Future<Result<Unit, RepositoryFailure>> deleteNote(
    NoteModel noteModel,
  ) async {
    try {
      await addNote(noteModel..removed = 1);

      return Result.success(unit);
    } catch (err) {
      return Result.failure(RepositoryFailure.fromError(err));
    }
  }

  @override
  Iterable<NoteModel> fetchRemovedNotesList() {
    /// get media file for this case
    return _databaseService.notesCollection
        .allNotes()
        .where((e) => e.removed == 1);
  }

  @override
  NoteModel? getLastUpdatedNote() {
    final realmResults = _databaseService.notesCollection.getLastUpdated();
    if (realmResults.isEmpty) return null;
    return realmResults.last;
  }

  @override
  NoteModel? getNote(String noteID) {
    return _databaseService.notesCollection.getSingle(noteID);
  }

  @override
  RealmResults<NoteModel> loadNotes() {
    return _databaseService.notesCollection.allNotes();
  }

  // @override
  // Future<Result<List<NoteModel>, RepositoryFailure>> getNotes(
  //   int offset,
  //   int limit,
  // ) async {
  //   try {
  //     /// get media file for this case
  //     final noteModels = await _apiClient.local.notesCollection.getAll();

  //     return Result<List<NoteModel>, RepositoryFailure>.success(noteModels);
  //   } catch (err) {
  //     return Result<List<NoteModel>, RepositoryFailure>.failure(
  //       RepositoryFailure.fromError(err),
  //     );
  //   }
  // }

  @override
  FutureOr<int> getTotalNoteCount() async {
    /// get media file for this case
    return _databaseService.notesCollection.countAll();
  }
}
