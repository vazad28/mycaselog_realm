import 'package:app_models/app_models.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:logger_client/logger_client.dart';
import 'package:realm/realm.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Abstract class defining [DatabaseCollection] structure
abstract class DatabaseCollection<T> with LoggerMixin {
  DatabaseCollection(this.userID, this.realm, this.sharedPrefs);

  final String userID;
  final Realm realm;
  final SharedPreferences sharedPrefs;

  /// Instance of firestore
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  /// root string and path string for server collections
  final String root = 'usersData';
  final String path = '';

  /// Last sync time in local storage
  final String _lastSyncTimestampKey = '${T}_lastSyncTimestampKey';
  String get lastSyncTimestampKey => _lastSyncTimestampKey;

  /// Collection ref for the collection
  CollectionReference<Map<String, dynamic>> get collectionRef =>
      firestore.collection(path);

  /// Firestore collectione stream
  late Stream<QuerySnapshot<Map<String, dynamic>>> _stream;
  Stream<QuerySnapshot<Map<String, dynamic>>> get stream => _stream;

  /// Get collection data converted to a Model
  CollectionReference<T> get withConverter =>
      throw UnimplementedError('withConverter not set');

  /// method to be overridden in collection for adding data
  /// to both local Realm and Firestore
  void upsert(String id, T Function() updateCallback) {
    final model = realm.write<T>(updateCallback);
    put(id, model);
  }

  /// stream to listen for collection change
  Stream<List<T>> listenForChanges();

  void createCollectionStream({int? lastSyncTimestamp}) {
    final timestamp = (lastSyncTimestamp ?? getLastSyncTimestamp) - 10000;
    _stream = collectionRef
        .where(
          'timestamp',
          isGreaterThan: timestamp < 0 ? 0 : timestamp,
        )
        .snapshots();
  }

  T? getSingle(String id);

  /// save the model
  Future<void> put(String docId, T model) => withConverter
          .doc(docId)
          .set(model)
          .then((_) => logger.info('success'))
          .catchError((dynamic err) {
        logger.severe(err.toString());
      });

  int get getLastSyncTimestamp =>
      sharedPrefs.getInt(_lastSyncTimestampKey) ?? 0;

  void setLastSyncTimestamp() {
    logger.fine('setLastSyncTimestamp for key - $_lastSyncTimestampKey');
    sharedPrefs.setInt(
      _lastSyncTimestampKey,
      ModelUtils.getTimestamp,
    );
  }
}
