import 'package:realm/realm.dart';

import '../../model_utils.dart';

part 'support_data_realm.realm.dart';

@RealmModel()
class _SupportDataRealm {
  @PrimaryKey()
  late String userID;
  late List<_AssistantRealm> assistants = [];
  late List<String> activeBasicFields = [];
  late List<String> anesthesiaBlocks = [];
  late List<_SurgeryLocationRealm> surgeryLocations = [];
  late int? timestamp;
}

extension SupportDataRealmX on SupportDataRealm {
  static SupportDataRealm zero(String userID) {
    final timestamp = ModelUtils.getTimestamp;

    final supportDataModel = SupportDataRealm(
      userID,
      timestamp: timestamp,
    );

    return supportDataModel;
  }
}

/// ////////////////////////////////////////////////////////////////////
/// Assistant Model
/// ////////////////////////////////////////////////////////////////////

@RealmModel()
class _AssistantRealm {
  @PrimaryKey()
  late String assistantID;
  late String? name;
  late String? phone;
  late String? photoUrl;
  late int? removed = 0;
  late int? createdAt = 0;
  late int? timestamp = 0;
}

extension AssistantRealmX on AssistantRealm {
  static AssistantRealm zero() {
    final timestamp = ModelUtils.getTimestamp;
    final assistantModel = AssistantRealm(
      ModelUtils.uniqueID,
      createdAt: timestamp,
      timestamp: timestamp,
    );

    return assistantModel;
  }
}

/// ////////////////////////////////////////////////////////////////////
/// Surgery Location Model
/// ////////////////////////////////////////////////////////////////////
@RealmModel()
class _SurgeryLocationRealm {
  @PrimaryKey()
  late String locationID;
  late String? name;
  late String? phone;
  late String? address;
  late int? removed = 0;
  late int? createdAt = 0;
  late int? timestamp = 0;
}

extension SurgeryLocationRealmX on SurgeryLocationRealm {
  static SurgeryLocationRealm zero() {
    final timestamp = ModelUtils.getTimestamp;
    final surgeryLocationModel = SurgeryLocationRealm(
      ModelUtils.uniqueID,
      createdAt: timestamp,
      timestamp: timestamp,
    );

    return surgeryLocationModel;
  }
}
