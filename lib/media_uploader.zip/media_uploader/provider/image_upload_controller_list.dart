import 'package:app_models/app_models.dart';
import 'package:collection/collection.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:logger_client/logger_client.dart';

import '../../settings/settings.dart';
import 'image_upload_controller.dart';
import '../domain/upload_controller.dart';

final imageUploadControllerList = Provider<ImageUploadControllersList>(
  ImageUploadControllersList.new,
);

class ImageUploadControllersList with LoggerMixin {
  final Ref ref;

  ImageUploadControllersList(this.ref);

  final Map<String, ImageUploadController> _uploadList = {};

  Map<String, ImageUploadController> get uploadList => _uploadList;

  void removeController(String mediaID) {
    _uploadList.remove(mediaID);
    //removeWhere((id, element) => id == mediaID);
  }

  ImageUploadController addController(
    MediaModel mediaModel,
  ) {
    final uploadFullSize = ref.read(appSettingsProvider).uploadFullSizePhoto;
    final controller = ImageUploadController(
      ref,
      mediaModel: mediaModel,
      uploadFullSize: uploadFullSize,
      onRemoveController: (String mediaID) {
        removeController(mediaID);
      },
    );

    _uploadList.putIfAbsent(mediaModel.mediaID, () => controller);

    print('upload controller list ${_uploadList.length}');
    return controller;
  }

  UploadController? getUploadController(MediaModel mediaModel) {
    if (mediaModel.status == MediaStatus.success ||
        mediaModel.status == MediaStatus.cancelled) return null;

    final entry = _uploadList.entries
        .firstWhereOrNull((element) => element.key == mediaModel.mediaID);

    return entry?.value ?? addController(mediaModel);
  }
}
